<?php
	header("HTTP/1.1 200 OK");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>200 OK : Comanda esborrada</title>
	</head>
	<body>
		<h2>200 OK : La comanda s'ha esborrat amb èxit</h2>		
		<a href="EsbCom.html"/><input type=button value='OK'></a>	
	</body>
</html>

