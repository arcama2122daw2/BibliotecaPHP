<INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);">

<?php
$prueba=fopen("Bibliotecaris/Bibliotecaris.txt","r") or die ("Error en intentar obriu l'arxiu");

while(!feof($prueba)){
    $linea=fgets($prueba);

    $saltodelinea=nl2br($linea);

    Echo $saltodelinea;

}
fclose($prueba);

?>