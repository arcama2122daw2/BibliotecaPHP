<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php
    if ($_POST["post"]=="LOGIN"){
        $prueba=fopen("Bibliotecaris/bibliotecari.txt","r") or die ("Error al llegir");
        while(!feof($prueba)){//recorre el archivo del text hasta que no quede línea
            $linea=fgets($prueba);

        $saltodelinea=nl2br($linea); //new line to <br>
        echo $saltodelinea;
    }else{
        echo "ERROR 405 MÈTODE NO PERMÉS<br>";
        echo "No s'ha validat el Login";
    } 
}
    fclose($prueba);
?>

</head>
<body>
<form action="http://localhost/projecte/validar_alta_bibliotecari.php" method="post">
    <input type="hidden" name="metode" value="bibliotecari_crear" />
    <h1>Quina acció vols realitzar?: </h1><br>

    <button type="submit" name="crear">Crear</button>
    <button type="submit" name="visualitzar">Visualitzar</button>
    <button type="submit" name="Modificar">Modificar</button>
    <button type="submit" name="Eliminar">Eliminar</button>
    </form>
    
</body>
</html>
