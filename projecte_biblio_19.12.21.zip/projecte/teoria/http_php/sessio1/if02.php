<?php
	//VARIABLES
	$LIM1=10;
	$LIM2=7;
	//MOSTRA VARIABLE
	//echo $LIM1;
	//echo "$LIM1\n";
	echo "$LIM1<br>\n";
	//echo $LIM2;
	//echo "$LIM2\n";
	echo "$LIM2<br>\n";
	//CODI IF AMB NOMES 1 INSTRUCCIÓ NO CAL { }
	if ($LIM2 > $LIM1) echo "$LIM2 és més gran que $LIM1\n";
	else echo "$LIM2 és més petit que $LIM1\n";
?>
