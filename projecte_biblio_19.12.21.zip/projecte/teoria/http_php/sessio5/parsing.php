<html>
<head>
	<title>PARSING AMB VARIABLES</title>
</head>
	<body>
		<?php
			error_reporting(0);
			$moneda00="Euro";
			$moneda01="Dolar";
			$canvi=1.17;
			$quantitat00=500;
			$quantitat01=$canvi*$quantitat00;
			echo "Sense parsing --> $quantitat00 $moneda00s són $quantitat01 $moneda01s<br>"; //$monedas00s no existeix, per tant en el moment d'executar ens donarà error.
			echo "Amb parsing --> $quantitat00 ${moneda00}s són $quantitat01 ${moneda01}s<br>";	//fora de corchete no és nom de variable. Entre corxetes "moneda00" estem cridant la variable.els corxetes delimiten quina part del string es nom de variable	
		?>	
	</body>
</html>
