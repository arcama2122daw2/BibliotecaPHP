<?php
	$usuari="145056.clot@fje.edu";
	$pwd="aP@35#Km";
	//https://developer.mozilla.org/en-US/docs/Web/HTTP/Authentication#authentication_schemes
	//https://www.php.net/manual/en/features.http-auth.php
	// $_SERVER --> https://www.php.net/reserved.variables.server
	if (!isset($_SERVER['PHP_AUTH_USER'])){
		header('HTTP/1.1 401 Unauthorized');
		header('WWW-Authenticate: Basic realm="Area privada"');
		die("Intent d'accés cancel·lat per l'usuari. Sense autenticació no hi ha accés a la data de l'examen");
		// die() = echo + exit()		
	}
	else{
		if (($_SERVER['PHP_AUTH_USER']==$usuari) && ($_SERVER['PHP_AUTH_PW']==$pwd)){ 
			echo "La data de l'examen del M17UF8 és el dia 21-5-2022<br>";
		}
		else{
			header('HTTP/1.1 401 Unauthorized');
			die("Autenticació errònia");
		}
	}
?>
	

			
