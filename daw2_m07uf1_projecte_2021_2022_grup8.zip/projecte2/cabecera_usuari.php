<?php
session_start();
if(isset ($_SESSION['nom'])!='Costal111'){
    header("Location:Login_usuari.php");

    $nom_cookie = "Costal111";
    $valor_cookie = "Bibliotecari";
    setcookie($nom_cookie, $valor_cookie);

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
    <input type="hidden" name="metode" value="bibliotecari_crear" />
    <h1>Quina acció vols realitzar?:</h1><br>
    
    <a href="cerrar_sesion.php">Cerrar Sesion</a><br><br>

    Llibres<br>
    <a href="visualitzar_llibres_disponibles.php">Visualitzar Llibre Disponible</a><br>
    <a href="visualitzar_llibres.php">Visualitzar Llibres</a><br><br>

    Usuaris<br>
    <a href="visualitzar_usuari.php">Veure dades Usuari</a><br>


    </form> 
</body>
</html>