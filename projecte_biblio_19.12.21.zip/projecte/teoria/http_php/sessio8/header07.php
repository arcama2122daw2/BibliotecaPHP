<?php
	header("Refresh:5; url=header.html");
	echo "Hola. En 5 segons serà redirigit cap a header.html";	
?>
	

			
