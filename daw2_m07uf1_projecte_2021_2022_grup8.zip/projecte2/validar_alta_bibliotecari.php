<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alta realitzada</title>
    <?php
        session_start();
        echo "<b>CREANT UN FITXER I ESCRIVINT</b><br>";
        $ID = $_POST['ID'];
        $password = $_POST['pass'];
        $nom = $_POST['nom'];
        $adreca = $_POST['adreca'];
        $email = $_POST['correu'];
        $telefon = $_POST['telefon'];
        $seguretatsocial = $_POST['seguretat_social'];
        $datainici = $_POST['data_inici'];
        $salari = $_POST['salari'];
        $bibliotecaricap= $_POST['capsi_capno'];

        if ($_POST["metode"]=="ALTA_BIBLIOTECARI"){
            $filename="Bibliotecaris.txt";
            $fitxer=fopen("Bibliotecaris.txt","a") or die ("No s'ha pogut crear el fitxer");
            $texte = $ID.":".$password.":".$email.":".$telefon.":".$nom.":".$adreca.":".$seguretatsocial.":".$datainici.":".$salari.":".$bibliotecaricap;
            fwrite($fitxer,$texte);
            fclose($fitxer);
            echo "El fitxer s'ha creat correctament<br>";
        }else{
            echo "ERROR 405 MÈTODE NO PERMÉS<br>";
            echo "No s'ha validat el bibliotecari";
        }
    ?>
</head>
<body>
</body>
</html>