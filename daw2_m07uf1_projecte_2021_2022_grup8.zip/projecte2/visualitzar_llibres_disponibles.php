<INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);">

<?php
$prueba=fopen("gestio_llibre/validar_llibre_disponible.txt","r") or die ("Error en intentar obriu l'arxiu");

while(!feof($prueba)){
    $linea=fgets($prueba);

    $saltodelinea=nl2br($linea);

    Echo $saltodelinea;

}
fclose($prueba);

?>