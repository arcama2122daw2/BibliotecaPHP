</html>
<head>
	<meta content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Arrays - IV</title>
</head>  
<body>  
<?php
	//Array associatiu. Treballant amb foreach i mostrant només valors.
	echo "<u>ARRAY ASSOCIATIU. MOSTRA ELS VALORS</u><br>";
	$mitjanes=array("Pons" => 3, "Peris" => 7, "Ramírez" => 6);
	foreach ($mitjanes as $mitjana) {
		echo "La nota mitjana és ".$mitjana."<br>";
	}
	echo "<hr>";
	//
	//
	//Array associatiu. Treballant amb foreach i mostrant només claus.
	echo "<u>ARRAY ASSOCIATIUS. MOSTRA LES CLAUS</u><br>";
	$mitjanes=array("Pons" => 3, "Peris" => 7, "Ramírez" => 6);
	$claus=array_keys($mitjanes);
	echo "Llista de claus:<br>";
	for ($i = 0; $i < sizeof($claus); $i++) {
		echo "* $claus[$i]<br>";
	}
	echo "<hr>";
	//
	//
?> 
</body>
</html>


