<?php
	header("Refresh:5");
	// Refresh no forma part del protocol HTTP però ha esdevingut un
	// estàndard de facto que funciona a la majoria de navegadors
	echo date("YmdHis");
?>
	

			
