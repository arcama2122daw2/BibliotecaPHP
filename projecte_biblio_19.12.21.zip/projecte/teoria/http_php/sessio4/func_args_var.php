</html>
<head>
	<meta content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Funcions amb quantitat d'arguments variables</title>
</head>  
<body>  
<?php
	function mitjana(...$dades) { /*puc cridar la variable mitjana amb valors variables en cada crida*/ /*els 3 punts permetra treballar amb un num diferent de variables en cada crida*/
		$suma=0;
		foreach ($dades as $dada) { /* navegar perla variable*/
			$suma+=$dada;
		}
		$mitjana=$suma/(count($dades));
		return number_format($mitjana,2);
	}
	echo "La mitjana és: ".mitjana(1,3,4,5,6,9)."</br>";
	echo "La mitjana és: ".mitjana(1,4,5,6)."</br>";
	echo "La mitjana és: ".mitjana(1,4)."</br>";
	echo "La mitjana és: ".mitjana(1,4,5,6,8,9,0,3,2)."</br>";
?>
</body>
</html>
