<?php
  if( $_GET["nom"] || $_GET["edat"] )
  {
     echo "Benvingut ". $_GET['nom']. "<br />";
     echo "Tens ". $_GET['edat']. " anys";
     exit();
  }
?>
<html>
<body>
  <form action="<?php $_PHP_SELF ?>" method="GET">
  Nom: <input type="text" name="nom" />
  Edat: <input type="text" name="edat" />
  <input type="submit" />
  </form>
</body>
</html>
