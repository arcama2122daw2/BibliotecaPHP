<?php
	header("HTTP/1.1 404 Not Found");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Error 404 : La comanda no existeix</title>
	</head>
	<body>
		<h2>Error 404: Aquesta comanda no és accessible o no existeix</h2>		
		<a href="EsbCom.html"/><input type=button value='OK'></a>	
	</body>
</html>
