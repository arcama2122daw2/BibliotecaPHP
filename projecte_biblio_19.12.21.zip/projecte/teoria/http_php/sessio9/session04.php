<?php
	# Inicia sessió
	session_start();
	$id=session_id();
	# Destrucció (unset) de les variables de sessió
	session_unset();
	# Neteja les cookies de sessió
	$cookie_sessio = session_get_cookie_params();
	setcookie(session_name(),'',time() - 86400, $cookie_sessio['path'], $cookie_sessio['domain'], $cookie_sessio['secure'], $cookie_sessio['httponly']); 
	# Destrucció de la sessió
	session_destroy();
?>
<html>
	<head>
		<title>
			DESTRUCCIÓ DE SESSIONS
		</title>
		<body>
			SESSIÓ <?php echo $id?> DESTRUÏDA
		</body>
	</head>
</html>
