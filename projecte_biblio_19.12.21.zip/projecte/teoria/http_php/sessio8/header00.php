<?php
	$nom_cookie="test"; 
	$llengua="es-ca"; 
	$nova_url="header.html"; 
	header("set-cookie: name=$nom_cookie"); 
	header("Content-Language: $llengua");
	header("location: $nova_url");
?>
<html>
	<head>
		<title>header00</title>
  </head>
  <body>
	  Redirigint cap a la nova localització
  </body>
</html>
	
