<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php
        session_start();
        $usuario = $_POST["nom"];
        $password = $_POST["pass"];
        
        define("ARCHIVO_BIBLIOS", "Bibliotecari_nocap.txt");
        
        // Mostramos contenido del archivo
        
        $archivo = fopen("Bibliotecaris/Bibliotecari_nocap.txt", "r") or die("Error - No ha estat possible obrir l'arxiu");
            
        $encontrado=false;
        while ($linea = fgets($archivo)){
        $partes = explode(':', trim($linea));
                
            if (($usuario == $partes[0]) && ($password == $partes[1])){
                $encontrado=true;
                break;
            }    
        }
        
        if ($encontrado==true){
            $_SESSION['nom']="arnau111";
            header("Location:index_nocap.php");
        } else {
            echo "<script> alert('Usuario o contraseña incorrectos')</script>";
        }
        fclose($archivo);
        
    
    ?>
    