<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php
        session_start();
        $usuario = $_POST["nom"];
        $password = $_POST["pass"];
        
        define("ARCHIVO_BIBLIOTECARIOS", "bibliotecaris.txt");
        
        // Mostramos contenido del archivo
        
        $archivo = fopen("Bibliotecaris/bibliotecaris.txt", "r") or die("Error - No ha estat possible obrir l'arxiu");
            
        $encontrado=false;
        while ($linea = fgets($archivo)){
        $partes = explode(':', trim($linea));
                
            if (($usuario == $partes[0]) && ($password == $partes[1]) || ($usuario == $partes[2]) && ($password == $partes[3])){
                $encontrado=true;
                break;
            }    
        }
        
        if ($encontrado==true){
            echo "Has sido validado correctamente en la aplicación";
            header("Location:accions_bibliotecari_cap.php");
        } else {
            echo "<script> alert('Usuario o contraseña incorrectos')</script>";
        }
        
        fclose($archivo);
        
    
    ?>
    