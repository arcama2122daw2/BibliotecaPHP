<?php
	//VARIABLES
	$LIM1="a"; //Alternativa --> $LIM1='a';
	$LIM2="c";
	//MOSTRA VARIABLE
	echo "$LIM1<br>\n";
	echo "$LIM2<br>\n";
	//CODI IF EN GENERAL AMB STRINGS. STRING = 1 o més caràcters
	if ($LIM2 > $LIM1){
		echo "$LIM2 és més gran que $LIM1\n";
	} 
	else{
		echo "$LIM2 és més petit que $LIM1\n";
	}
?>
