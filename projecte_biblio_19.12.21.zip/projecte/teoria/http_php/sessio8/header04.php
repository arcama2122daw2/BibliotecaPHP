<?php
	header("Cache-control: public, max-age=300");
	header("Connection: close");
?>
<html>
	<head>
		<title>header04</title>
  </head>
  <body>
	  header04
  </body>
</html>
	
