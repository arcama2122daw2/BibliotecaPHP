<?php
  if( $_POST["nom"] || $_POST["edat"] )
  {
     echo "Benvingut ". $_POST['nom']. "<br />";
     echo "Tens ". $_POST['edat']. " anys";
     exit();
  }
?>
<html>
<body>
  <form action="<?php $_PHP_SELF ?>" method="POST">

  Nom: <input type="text" name="nom" />
  Edat: <input type="text" name="edat" />

  <input type="submit" />
  </form>
</body>
</html>
