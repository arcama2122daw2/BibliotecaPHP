<!-- /etc/php/7.3/cli/php.ini ==> Linia 220 output_buffering a 4096 (Mida del buffer 4096) --> 
<!-- /etc/php/7.3/apache2/php.ini ==> Linia 220 output buffering a 4096 (Mida del buffer 4096) -->
<!-- Reinici apache2 -->
<html>
	<head>
		<title>header02</title>
  </head>
  <body>
	  Redirigint cap a la nova localització
  </body>
</html>
<?php
	$nom_cookie="test"; 
	$llengua="es-ca"; 
	$nova_url="header.html"; 
	header("set-cookie: name=$nom_cookie"); 
	header("Content-Language: $llengua");
	header("location: $nova_url");
?>

