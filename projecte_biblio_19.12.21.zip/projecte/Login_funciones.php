<?php
if(isset($_POST['login'])){
	$nom = $_POST['usuari'];
	$contingut =$_POST['password'];

	if (file_get_contents("Bibliotecaris.txt")){
		echo "Arxiu amb nom d'usuari i contrasenya correcte";
	}else{
		echo "no s'ha creat cap arxiu";
	}
}
?>


file_put_contents("BibliotecariCap.txt", data, mode, context)