<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>interfície usuari</title>
</head>
<body>
    <form action=""></form>
    usuari: <br>
    <input type="text" name="nom"/><br><br>

    contrasenya: <br>
    <input type="password" name="pass"/><br><br>

    <button>Validar</button>    
</body>
</html>