 <?php
session_start();
?>
<!DOCTYPE html>
<html>
	<body>
		<b>TREBALLANT AMB $_SESSION: MOSTRANT LES DADES DES D'UNA ALTRA APLICACIÓ</b><br>	
		<?php
			if ($_SESSION["comptador"] == 1) {
				echo "S'ha entrat només 1 vegada a l'aplicació durant aquesta sessió.<br>";
				echo "No hi ha data de l'anterior visita perquè només s'ha fet un accés.<br>";
				echo "Identificador de sessió: ".session_id()."<br>";
			}
			else {
				echo "S'ha visitat la web: " . $_SESSION["comptador"] . " vegada durant aquesta sessió.<br>";
				echo "La data del darrer accés és: " . $_SESSION["data_darrer_acces"] . ".<br>";
				echo "Identificador de sessió: ".session_id()."<br>";
			}
			echo "##############################<br>";
			echo "Estructura de ".'$_SESSION'." <br>";
			foreach ($_SESSION as $clau => $valor) {
				echo '$_SESSION'."[$clau] = $valor</br>";
			}
		?>
	</body>
</html> 
