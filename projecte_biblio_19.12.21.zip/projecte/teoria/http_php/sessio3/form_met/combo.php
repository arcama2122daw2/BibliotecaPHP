<?php
		echo "Has demanat el viatge a ".$_POST["viatge"]."<br>";
		exit(0);
?>
