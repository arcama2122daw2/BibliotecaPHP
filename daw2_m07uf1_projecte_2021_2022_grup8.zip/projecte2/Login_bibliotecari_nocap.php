<INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estils.css">
    <title>Login</title>
</head>
<body>
    <form action="validar_login_nocap.php" method="POST" value="LOGIN">
        <div class="container">
          <label for="contenido"><b>Nom d'usuari</b></label>
          <input type="text" placeholder="Escriu nom d'usuari" name="nom" required>

          <label for="contenido"><b>Contrasenya</b></label>
          <input type="password" placeholder="Escriu contrasenya" name="pass" required>
              
          <button type="submit" name="botonverdelogin" value="login">Login</button>
        </div>
      </form>
</body>
</html>
