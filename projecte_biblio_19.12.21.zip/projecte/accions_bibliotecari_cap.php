<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="http://localhost/projecte/validar_alta_bibliotecari.php" method="post">
    <input type="hidden" name="metode" value="bibliotecari_crear" />
    <h1>Quina acció vols realitzar?:</h1><br>

    <a href="http://localhost/projecte/alta_bibliotecari_cap.php">Crear</a>
    <a href="">Visualitzar</a>
    <a href="">Modificar</a>
    <a href="">Eliminar</a>
    <a href="http://localhost/projecte/cerrar_sesion.php">Cerrar sesión</a>
    </form> 
</body>
</html>