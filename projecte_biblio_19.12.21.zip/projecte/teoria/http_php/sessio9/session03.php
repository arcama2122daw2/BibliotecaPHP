 <?php
session_start();
?>
<!DOCTYPE html>
<html>
	<body>
		<b>TREBALLANT AMB $_SESSION: ELIMINANT DADES D'UNA VARIABLE</b><br>	
		<?php
			unset($_SESSION["comptador"]);
			if (!isset($_SESSION["comptador"])) {
				echo "El comptador de visites durant la sessió ha estat eliminat.<br>";
				echo "Identificador de sessió: ".session_id()."<br>";
			}
			else echo "El comptador de visites durant la sessió val: " . $_SESSION["comptador"] . ".<br>";
			echo "##############################<br>";
			echo "Estructura de ".'$_SESSION'." <br>";
			foreach ($_SESSION as $clau => $valor) {
				echo '$_SESSION'."[$clau] = $valor</br>";
			}
		?>
	</body>
</html> 
