<?php
	# https://notlaura.com/output-buffering/
	# /etc/php/7.3/cli/php.ini --> Linia 220 output_buffering a Off
	# /etc/php/7.3/apache2/php.ini --> Linia 220 output buffering a Off
	# Reinici apache2
	# Prova amb ob_start/ob_end_flush comentat i sense comentat
	ob_start(); //Activa output buffering. https://www.w3schools.com/php/ref_output_ob_start.asp
	$nom_cookie="test"; //Variable a buffer
	$llengua="es-ca"; //Variable a buffer
	$nova_url="header.html"; //Variable a buffer
?>
	<html>
		<head>
			<meta http-equiv="content-type" content="text/html; charset=UTF-8">
			<title>
				header03.php
			</title>
		<head>
		<body>
			<font face="Arial">
				<b>LOCALITZACIÓ INICIALS</b><br>
			</font> 
		</body>
	<html>
<?php
	header("set-cookie: name=$nom_cookie"); 
	header("Content-Language: $llengua");
	header("location: $nova_url");
	ob_end_flush(); //outputs content from the buffer and ends output buffering. It does not erase the buffer.
	ob_clean();	//removes everything from the output buffer. Note that it does not output anything.
?>
