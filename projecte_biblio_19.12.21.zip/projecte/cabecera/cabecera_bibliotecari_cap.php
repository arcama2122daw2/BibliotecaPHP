<?php
session_start();
if(isset ($_SESSION['nom'])!='sergi222'){
    header("Location:Login_html.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="http://localhost/projecte/bibliotecari_crear.php">Crear</a>
    <a href="">Visualitzar</a>
    <a href="">Modificar</a>
    <a href="">Eliminar</a>
    <a href="projecte/accions_biblitoecari_cap.php">acacascas</a>
    
</body>
</html>