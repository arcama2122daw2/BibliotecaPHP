<?php
	header("HTTP/1.1 403 Not Found");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Error 403 : Permisos insuficients</title>
	</head>
	<body>
		<h2>Error 403: No té els permisos necessaris per esborrar la comanda</h2>		
		<a href="EsbCom.html"/><input type=button value='OK'></a>	
	</body>
</html>
