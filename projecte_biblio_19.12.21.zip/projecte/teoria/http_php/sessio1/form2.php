<?php
	echo "<b>Dades introduïdes al formulari:</b><br>";
	echo "El teu nom és:".$_GET["nom"]."<br>";
	echo "El teu primer cognom és:".$_GET["cognom1"]."<br>";
	echo "El teu segon cognom és:".$_GET["cognom2"];
?>
