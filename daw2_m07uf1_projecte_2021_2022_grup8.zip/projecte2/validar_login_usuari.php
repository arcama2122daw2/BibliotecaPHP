<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php
        session_start();
        $usuario = $_POST["nomu"];
        $password = $_POST["passu"];
        
        define("ARCHIVO_USUARIOS", "Validar_usuari.txt");
        
        // Mostramos contenido del archivo
        
        $archivo = fopen("alta_usuaris/Validar_usuari.txt", "r") or die("Error - No ha estat possible obrir l'arxiu");
            
        $encontrado=false;
        while ($linea = fgets($archivo)){
        $partes = explode(':', trim($linea));
                
            if (($usuario == $partes[0]) && ($password == $partes[1])){
                $encontrado=true;
                break;
            }    
        }
        
        if ($encontrado==true){
            $_SESSION['nomu']="Costal111";
            header("Location:index_usuari.php");
        } else {
            echo "<script> alert('Usuario o contraseña incorrectos')</script>";
        }
        fclose($archivo);
        
    
    ?>
    