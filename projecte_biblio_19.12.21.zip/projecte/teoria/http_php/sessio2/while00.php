<html>
<head>
	<title>PROVA DE PHP AMB L'ESTRUCTURA DE CONTROL WHILE</title>
</head>
	<body>
		<b><u>INICI DE LA PROVA DE ESTRUCTURA DE CONTROL WHILE</u></b><br>
		<?php
			//VARIABLE
			$x = 5;
			$LIM = 14;
			//CODI SWITCH EN GENERAL
			while ($x <= $LIM){
				echo "$x és menor o igual a $LIM<br>\n";
				$x++;
			}
		?>
		<b>FINAL DE LA PROVA DE L'ESTRUCTURA DE CONTROL WHILE</b>
	</body>
</html>
