<?php
session_start();
if(isset ($_SESSION['nom'])!='arnau111'){
    header("Location:Login_bibliotecari_nocap.php");
}

$nom_cookie = "arnau111";
$valor_cookie = "Bibliotecari";
setcookie($nom_cookie, $valor_cookie);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
    <input type="hidden" name="metode" value="bibliotecari_crear" />
    <h1>Quina acció vols realitzar?:</h1><br>

    <a href="cerrar_sesion.php">Cerrar Sesion</a><br><br>

    Bibliotecaris<br>

    <a href="visualitzar_bibliotecari.php">Visualitzar Bibliotecari</a><br><br>
    
    Llibres<br>

    <a href="alta_llibres.php">Crear Llibre</a><br>
    <a href="visualitzar_llibres.php">Visualitzar Llibre</a><br>
    <a href="">Modificar LLibre</a><br>
    <a href="">Eliminar Llibre</a><br><br><br>

    Usuaris<br>
    <a href="alta_client.php">Crear Usuari</a><br>
    <a href="visualitzar_usuari.php">Visualitzar Usuari</a><br>
    <a href="">Modificar Usuari</a><br>
    <a href="">Eliminar Usuari</a><br>

    </form> 
</body>
</html>